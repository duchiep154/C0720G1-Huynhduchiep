package _07_abstract_interface;

public class PhapSuDepGai extends PhapSu implements IVuKhi {
    public PhapSuDepGai(String ten) {
        super(ten);
    }

    @Override
    public void nhiemVu(String tenNhiemVu) {

    }

    @Override
    public void getVuKhi(String tenVuKhi) {

    }
}
