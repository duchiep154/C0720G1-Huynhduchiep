package _07_abstract_interface;

public abstract class PhapSu extends DungSi {
    public PhapSu(String ten) {
        super(ten);
    }
}
