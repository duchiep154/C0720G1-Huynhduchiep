package _07_abstract_interface;

public interface IGiap {
    String capDo = "88";

    void getGiap(String tenGiap);
}
