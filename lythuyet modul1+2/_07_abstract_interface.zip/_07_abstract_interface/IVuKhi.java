package _07_abstract_interface;

public interface IVuKhi {
   String capDo = "99";

   void getVuKhi(String tenVuKhi);
}
