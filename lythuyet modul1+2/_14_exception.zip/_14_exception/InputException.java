package _14_exception;

public class InputException extends Exception{
    public InputException(String message) {
        super(message);
    }
}
