package _04_oop;

public class Test {
    public static void main(String[] args) {
        MyClass myClass = new MyClass(15);
        myClass.setAge(19);
        System.out.println(myClass.getAge());

    }
}
