package class_object;

public class TestStopWatch {
    public static void main(String[] args) {
        StopWatch stopWatch = new StopWatch();

        // goi phuong thuc start() cua stopwatch de bam gio bat dau

        // tao array voi 100.000 so voi cac so duoc random la 0 - 100.000
        // moi phan tu se random la [min, max] (Math.random() * (max - 0)) + min)
        // sap xep chon (selection sort)

        // goi phuong thuc stop() cua stopwatch de bam gio ket thuc

        // in ra thoi gian giua start va end boi phuong thuc getElapsedTime()
    }

    // static: dinh nghia phuong thuoc selection sort o day
}
