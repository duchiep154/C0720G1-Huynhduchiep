create database baihoc;
drop database baihoc;