package bai1_introction_to_java;

import java.util.Date;

public class HienThiThoiGianHeThongTH {
    public static void main(String[] args) {
        Date now = new Date();

        System.out.println("Now is: " + now);
    }
}