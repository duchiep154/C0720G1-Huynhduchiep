package bai1_introction_to_java;

public class KhaiBaoSuDungBienTH {
    public static void main(String[] args) {
        int i = 10;
        float f = 20.5f;
        double d = 20.5d;
        boolean b = true;
        char c = 'a';
        String s = "Hà Nội";
        System.out.println("i = " + i);
        System.out.println("f = " + f);
        System.out.println("d = " + d);
        System.out.println("b = " + b);
        System.out.println("c = " + c);
        System.out.println("s = " + s);
    }
}
