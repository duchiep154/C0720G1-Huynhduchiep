package bai12_java_collection_framework.thuc_hanh.optional.cai_dat_tim_kiem_nhi_phan;

public abstract class AbstractTree<E> implements Tree<E> {
    @Override
    /** Inorder traversal from the root*/
    public void inorder() {
    }
}
