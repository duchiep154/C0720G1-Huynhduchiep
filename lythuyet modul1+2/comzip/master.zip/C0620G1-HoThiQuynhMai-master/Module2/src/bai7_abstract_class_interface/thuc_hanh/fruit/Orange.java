package bai7_abstract_class_interface.thuc_hanh.fruit;

public class Orange extends Fruit {
    @Override
    public String howToEat() {
        return "Orange could be juiced";
    }
}
