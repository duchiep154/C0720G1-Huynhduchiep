package bai7_abstract_class_interface.thuc_hanh.animal;

public abstract class Animal {
    public abstract String makeSound();
}