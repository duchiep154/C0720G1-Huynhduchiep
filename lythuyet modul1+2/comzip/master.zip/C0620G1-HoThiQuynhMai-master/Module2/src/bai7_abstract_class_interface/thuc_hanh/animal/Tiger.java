package bai7_abstract_class_interface.thuc_hanh.animal;

public class Tiger extends Animal {
    @Override
    public String makeSound() {
        return "Tiger: roarrrrr!";
    }
}