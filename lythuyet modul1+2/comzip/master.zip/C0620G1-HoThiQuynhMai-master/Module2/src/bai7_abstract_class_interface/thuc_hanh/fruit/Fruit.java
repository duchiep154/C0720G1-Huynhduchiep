package bai7_abstract_class_interface.thuc_hanh.fruit;

import bai7_abstract_class_interface.thuc_hanh.edible.Edible;

public abstract class Fruit implements Edible {

}