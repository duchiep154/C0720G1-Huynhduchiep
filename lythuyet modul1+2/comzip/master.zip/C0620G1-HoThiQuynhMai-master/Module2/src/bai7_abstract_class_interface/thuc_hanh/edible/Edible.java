package bai7_abstract_class_interface.thuc_hanh.edible;

public interface Edible {
    String howToEat();
}
