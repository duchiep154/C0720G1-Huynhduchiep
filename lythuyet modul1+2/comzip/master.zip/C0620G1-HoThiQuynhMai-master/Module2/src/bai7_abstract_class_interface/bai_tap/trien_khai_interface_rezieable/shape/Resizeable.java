package bai7_abstract_class_interface.bai_tap.trien_khai_interface_rezieable.shape;

public interface Resizeable {
    void resize(double percent);
}