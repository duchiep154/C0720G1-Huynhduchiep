package bai7_abstract_class_interface.bai_tap.trien_khai_interface_colorable;

public interface Colorable {
    void howToColor();
}
