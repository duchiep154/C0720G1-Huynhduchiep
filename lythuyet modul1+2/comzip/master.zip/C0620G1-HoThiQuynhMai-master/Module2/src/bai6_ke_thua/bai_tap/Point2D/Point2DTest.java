package bai6_ke_thua.bai_tap.Point2D;

public class Point2DTest {
    public static void main(String[] args) {
        Point2D point2D_1 = new Point2D();
        System.out.println(point2D_1);

        Point2D point2D_2 = new Point2D(3.5f, 6.5f);
        System.out.println(point2D_2);
    }
}
