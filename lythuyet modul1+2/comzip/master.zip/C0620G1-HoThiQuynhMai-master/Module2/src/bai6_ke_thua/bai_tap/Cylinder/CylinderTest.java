package bai6_ke_thua.bai_tap.Cylinder;

public class CylinderTest {
    public static void main(String[] args) {
        Cylinder cylinder1 = new Cylinder();
        System.out.println(cylinder1);

        Cylinder cylinder2 = new Cylinder(5,5,"green");
        System.out.println(cylinder2);
    }
}
