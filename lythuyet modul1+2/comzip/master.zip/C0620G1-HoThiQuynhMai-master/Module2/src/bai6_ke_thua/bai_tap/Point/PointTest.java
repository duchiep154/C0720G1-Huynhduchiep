package bai6_ke_thua.bai_tap.Point;

public class PointTest {
    public static void main(String[] args) {
        Point point_1 = new Point();
        System.out.println(point_1);

        Point point_2 = new Point(5.5f, 7.0f);
        System.out.println(point_2);
    }
}
