package bai6_ke_thua.bai_tap.Point3D;

public class Point3DTest {
    public static void main(String[] args) {
        Point3D point3D_1 = new Point3D();
        System.out.println(point3D_1);

        Point3D point3D_2 = new Point3D(1.0f,2.0f,3.5f);
        System.out.println(point3D_2);
    }
}
