package bai6_ke_thua.bai_tap.Circle;

public class CircleTest {
    public static void main(String[] args) {
        Circle circle = new Circle();
        System.out.println(circle);

        circle = new Circle(3,"green");
        System.out.println(circle);
    }
}
