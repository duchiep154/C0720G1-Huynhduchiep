package bai_thi.commons;

public class NotFoundDirectoryException extends Exception {
    public void thongBao(){
        System.out.println("Danh bạ không tồn tại");
    }
}
