package bai9_automated_testing_and_tdd.thuc_hanh.tim_gia_tri_tuyet_doi;

public class AbsoluteNumberCalculator {
    public static int findAbsolute(int number){
        if(number < 0)
            return  -number;
        return number;
    }
}