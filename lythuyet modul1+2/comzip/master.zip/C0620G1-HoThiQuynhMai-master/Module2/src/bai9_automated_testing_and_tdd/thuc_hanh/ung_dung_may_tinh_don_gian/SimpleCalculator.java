package bai9_automated_testing_and_tdd.thuc_hanh.ung_dung_may_tinh_don_gian;

public class SimpleCalculator {
    public static int add(int first, int second){
        return first + second;
    }

    public static int sub(int first, int second){
        return first - second;
    }
}

