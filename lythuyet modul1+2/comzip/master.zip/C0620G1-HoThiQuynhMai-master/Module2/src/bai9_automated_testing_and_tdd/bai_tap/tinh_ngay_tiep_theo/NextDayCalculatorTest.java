package bai9_automated_testing_and_tdd.bai_tap.tinh_ngay_tiep_theo;

import org.junit.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

//public class NextDayCalculatorTest {
//    @Test
//    public void testNextDay0() {
//        int day = 1;
//        int month = 1;
//        int year = 2018;
//        int expected = 2;
//
//        String result = NextDayCalculator.timNgayHomSau(day,month,year);
//        assertEquals(expected, result);
//    }

