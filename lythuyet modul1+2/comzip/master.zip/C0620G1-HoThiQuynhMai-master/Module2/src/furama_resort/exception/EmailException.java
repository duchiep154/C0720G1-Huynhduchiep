package furama_resort.exception;

import java.util.Scanner;

public class EmailException extends Exception {
}
