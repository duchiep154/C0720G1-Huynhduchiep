package furama_resort.exception;

public class NameException extends Exception {
}
