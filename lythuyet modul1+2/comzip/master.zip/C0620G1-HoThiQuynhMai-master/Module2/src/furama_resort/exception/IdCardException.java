package furama_resort.exception;

public class IdCardException extends Exception {
}
