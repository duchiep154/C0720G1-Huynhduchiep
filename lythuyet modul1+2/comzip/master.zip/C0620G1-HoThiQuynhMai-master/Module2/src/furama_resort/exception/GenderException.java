package furama_resort.exception;

import java.util.Scanner;

public class GenderException extends Exception {
}
