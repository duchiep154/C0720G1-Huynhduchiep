package furama_resort.exception;

public class BirthdayException extends Exception {
}
