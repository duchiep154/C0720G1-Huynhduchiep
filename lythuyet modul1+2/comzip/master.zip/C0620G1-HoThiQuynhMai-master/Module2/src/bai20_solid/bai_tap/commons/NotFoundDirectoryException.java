package bai20_solid.bai_tap.commons;

public class NotFoundDirectoryException extends Exception {
    public void thongBao(){
        System.out.println("Danh bạ không tồn tại");
    }
}
