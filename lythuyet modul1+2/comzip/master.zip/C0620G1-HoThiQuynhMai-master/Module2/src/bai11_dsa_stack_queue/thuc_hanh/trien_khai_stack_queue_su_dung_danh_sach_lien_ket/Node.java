package bai11_dsa_stack_queue.thuc_hanh.trien_khai_stack_queue_su_dung_danh_sach_lien_ket;

class Node {
    public int key;
    public Node next;

    public Node(int key) {
        this.key = key;
        this.next = null;
    }
}

