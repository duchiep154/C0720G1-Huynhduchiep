package _16_binary_file;

public class ABC extends Student{

    public ABC(int id, String name) {
        super(id, name);
    }
}
