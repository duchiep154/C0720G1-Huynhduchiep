package casting;

public class Animal {
    public String eyes;

    public void growl() {
        System.out.println("Unknown growl.");
    }

    public void move() {
        System.out.println("Unknown move.");
    }
}
