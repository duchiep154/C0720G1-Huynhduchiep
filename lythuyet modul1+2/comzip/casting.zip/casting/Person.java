package casting;

public class Person extends Animal {
    public String hands;
    public String legs;

    @Override
    public void move() {
        System.out.println("Move by legs");
    }
}
